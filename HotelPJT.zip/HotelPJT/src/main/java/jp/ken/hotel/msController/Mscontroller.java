package jp.ken.hotel.msController;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.ken.hotel.model.HotelDAO;
import jp.ken.hotel.model.HotelDTO;

@Controller
public class Mscontroller {
	
	@Autowired
	private HotelDAO hotelDao;
	
	
	@RequestMapping(value = "master", method = RequestMethod.GET)
	public String Tomaster(@ModelAttribute HotelDTO hotelDot, Model model) {
		
		List<HotelDTO> hotelList = hotelDao.masterList();
		model.addAttribute("hotelList", hotelList);
		
		return "master";
	}
	
	@RequestMapping(value = "login", method = RequestMethod.GET)
	public String tologin() {
		
		return "login";
	}
	
	@RequestMapping(value = "join", method = RequestMethod.GET)
	public String toJoing() {
		return "join";
	}
	
	@RequestMapping(value = "view", method = RequestMethod.GET)
	public String toView() {
		return "view";
	}
	
	@RequestMapping(value = "start", method = RequestMethod.GET)
	public String toStart() {
		return "start";
	}

}
